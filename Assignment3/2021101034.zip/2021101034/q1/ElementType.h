#ifndef _ELEMENT_TYPE_H_
#define _ELEMENT_TYPE_H_
#define NOELEMENT -1
#include "treenode.h"

typedef TreeNode ElementType;

#endif